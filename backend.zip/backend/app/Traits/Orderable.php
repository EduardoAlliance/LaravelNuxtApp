<?php
/**
 * Created by PhpStorm.
 * User: osx
 * Date: 24/10/20
 * Time: 22:21
 */

namespace App\Traits;


trait Orderable
{
    public function scopeLatestFirst($query){
        $query->orderBy('created_at','desc');
    }

    public function scopeOldestFirst($query){
        $query->orderBy('created_at','asc');
    }
}