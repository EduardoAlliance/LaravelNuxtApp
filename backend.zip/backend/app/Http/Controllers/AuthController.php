<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserLoginRequest;
use App\Http\Requests\UserRegisterRequest;
use App\Models\User;
use App\Http\Resources\User as UserResource;
use Illuminate\Http\Request;

class AuthController extends Controller
{

    public function __construct(){
        $this->middleware('auth:api', ['except' => ['login','register']]);
    }

    public function register(UserRegisterRequest $request){
       $user = User::create([
          'email'=>$request->email,
           'name'=>$request->name,
           'password'=>bcrypt($request->password),
       ]);
       return $this->returnUser($request);
    }

    public function login(UserLoginRequest $request){
        return $this->returnUser($request);
    }

    public function logout(){
        auth()->logout();
        return response()->json(['message' => 'Successfully logged out']);
    }

    public function user(Request $request){
        return new UserResource(auth()->user());
    }

    private function returnUser($request){
        if(!$token = auth()->attempt($request->only(['email','password']))){
            return response()->json([
                'errors'=>[
                    'email' => trans('auth.failed')
                ]
            ]);
        }
        return (new UserResource(auth()->user()))->additional([
            'meta'=>[
                'token'=> $token,
                'token_type' => 'bearer',
                'expires_in' => auth()->factory()->getTTL() * 60
            ]
        ]);
    }
}
