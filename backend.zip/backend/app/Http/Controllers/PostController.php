<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Topic;
use App\Http\Requests\StorePostRequest;
use App\Http\Requests\UpdatePostRequest;
use App\Http\Resources\Post as PostResource;

class PostController extends Controller
{

    public function index()
    {
        //
    }

    public function store(StorePostRequest $request, Topic $topic)
    {
        try{
            $post = new Post();
            $post->body = $request->body;
            $post->user()->associate($request->user());
            $topic->posts()->save($post);
            return new PostResource($post);
        }catch (\Exception $e){
            return response()->json(['error'=>$e->getMessage()],500);
        }
    }


    public function show(Topic $topic, Post $post)
    {
        return new PostResource($post);
    }

    public function update(UpdatePostRequest $request,Topic $topic, Post $post)
    {

        try{
            $this->authorize('update',$post);
            $post->body = $request->body;
            $post->save();
            return new PostResource($post);
        }catch (\Exception $e){
            return response()->json(['error'=>$e->getMessage()],500);
        }
    }

    public function destroy(Topic $topic, Post $post)
    {
        try{
            $this->authorize('destroy',$post);
            $post->delete();
            return response(null,204);
        }catch (\Exception $e){
            return response()->json(['error'=>$e->getMessage()],500);
        }
    }
}
